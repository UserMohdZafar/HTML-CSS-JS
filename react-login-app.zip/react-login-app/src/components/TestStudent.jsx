import { Typography } from "@mui/material";
import { Box } from "@mui/system";
import {Home } from '@material-ui/icons'

const TestStudent = () => {
    return (
        <>
        <Box>
            <Typography variant='h4'> <Home fontSize="large" /> componentWillUnmount functionalty </Typography>
        </Box>
        </>
    )
}

export default TestStudent;