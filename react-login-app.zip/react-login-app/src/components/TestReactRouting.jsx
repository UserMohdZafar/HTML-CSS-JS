// import {BrowserRouter, Route, NavLink  } from "react-router-dom";
// import { Switch, Typography } from "@mui/material";

// const TestReactRouting = () => {

//     return (
//         <BrowserRouter>
//             <NavLink to='/home' exact="true">HomePage</NavLink> &nbsp; 
//             <NavLink to='/about' exact="true">AboutPage</NavLink>
//             <Switch>
//                 <Route path="/home" element={<Home />}  exact></Route>
//                 <Route path="/about" element={<About />}  exact></Route>
//             </Switch>
//         </BrowserRouter>
//     )
// }
// function Home(){
//     return (
//         <>
//             <Typography variant='h5'> ------------------ Home Page ------------------ </Typography>
//         </>
//     )
// }

// function About(){
//     return (
//         <>
//             <Typography variant='h5'> ------------------ About Page ------------------ </Typography>
//         </>
//     )
// }

// export default TestReactRouting;