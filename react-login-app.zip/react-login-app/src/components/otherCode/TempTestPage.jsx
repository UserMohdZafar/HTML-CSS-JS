import React from 'react'

function TempTestPage() {
  return (
    <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis illo sint voluptate in ipsa aliquid qui veritatis eius saepe dignissimos repudiandae exercitationem est ratione animi praesentium fugiat alias distinctio dolores, deleniti reprehenderit impedit. Nihil consequatur labore, laboriosam nulla velit repellat nemo laudantium natus animi sapiente nam atque quos! Optio maxime soluta accusamus. Animi ex temporibus, nobis deserunt, in, dolorum esse reprehenderit numquam velit ducimus aliquam dolore saepe. Dolores quam cumque corporis, hic unde porro odio eaque libero asperiores voluptatum odit aspernatur vel. Assumenda illo cupiditate culpa in, obcaecati esse aspernatur quidem ut ab possimus perspiciatis dolorum incidunt perferendis officiis odit!</div>
  )
}

export default TempTestPage